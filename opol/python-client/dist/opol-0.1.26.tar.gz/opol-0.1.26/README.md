This is the python wrapper to interact with all OPOL services.

## Installation

```bash
pip install opol
```

